#!/usr/bin/perl

use IO::Socket;

# Read in STDIN args
if ($#ARGV != 3) 
{
	print "Usage: ./udpserver <port> <host> <file> <n-times>\n";
	exit;
}

# Set vars
$PORT=$ARGV[0];
$HOST=$ARGV[1];
$FILENAME=$ARGV[2];
$MAXCOUNT=$ARGV[3];

$COUNT=0;
$KILLSIG="_EXIT_IMMEDIATELY_";
$TIMEOUT=4;

$socket = new IO::Socket::INET (
                                  PeerAddr  => $HOST,
                                  PeerPort  => $PORT,
                                  Proto => 'tcp',
                               ) or die "Can't connect to Server\n";
    
		print "\nBlasting port $PORT at $HOST with TCP packets from file $FILENAME\n";
		
        open ( FILEHANDLE, "<$FILENAME") or die ("\nWARNING: Cannot open $FILENAME\n\n");
		
        while ($COUNT < $MAXCOUNT)
        {
			read ( FILEHANDLE, $newText, 1);
            $send_data .= $newText;
				 
			if($send_data)
			{
				$socket->send($send_data);
			}
			$COUNT++;
        }
		
		
		$socket->send($KILLSIG);
		close($socket);
		exit(1);
		
    